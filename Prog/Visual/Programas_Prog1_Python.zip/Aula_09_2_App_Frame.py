from tkinter import *

class Janela_Top(Toplevel):
    def __init__(self, Master, Str="Janela", x1="0", y1="0", dx="640", dy="480", cor="ligthgray"):
        super(Janela_Top, self).__init__(Master)
        super(Janela_Top, self).title(Str)
        super(Janela_Top, self).geometry("%sx%s+%s+%s" % (dx, dy, x1, y1))
        super(Janela_Top, self).configure(bg=cor)

        self.inicialize()

    def inicialize(self):
        Lb1=Label(self, text="First Name")
        Lb1.grid(row=0, column=0)

########################################################################################################################

class Janela(Tk):
    def __init__(self, Str="Janela", x1="0", y1="0", dx="640", dy="480", cor="ligthgray"):
        super(Janela, self).__init__()
        super(Janela, self).title(Str)
        super(Janela, self).geometry("%sx%s+%s+%s" % (dx, dy, x1, y1))
        super(Janela, self).configure(bg=cor)

        self.inicialize()

    def action_window(self):
        Jan2 = Janela_Top(self, "Minha janela", "600", "400", "340", "280", "cyan")

    def action_quit(self):
        self.quit()

    def inicialize(self):
        Lb1=Label(self, text="First Name")
        Lb2=Label(self, text="Last Name")
        Lb3=Label(self, text="Text área")

        Et1=Entry(self, width=52)
        Et2=Entry(self, width=52)

        Txt1=Text(self, height=8, width=40)

        Bt1=Button(self, text='Quit', command=self.action_quit)
        Bt2=Button(self, text='New window', command=self.action_window)

        Lb1.grid(row=0, column=0)
        Lb2.grid(row=1, column=0)
        Lb3.grid(row=3, column=0)
        Et1.grid(row=0, column=1, columnspan=2)
        Et2.grid(row=1, column=1, columnspan=2)
        Txt1.grid(row=3, column=1, columnspan=2)
        Bt1.grid(row=4, column=1, sticky=E, padx=4, pady=4)
        Bt2.grid(row=4, column=2, sticky=W, padx=4, pady=4)

########################################################################################################################

Jan1=Janela("Minha janela", "400", "200", "540", "380", "orange")
Jan1.mainloop()
