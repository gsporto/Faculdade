from tkinter import *

class Janela(Tk):
    def __init__(self, Str="Janela", x1="0", y1="0", dx="640", dy="480", cor="ligthgray"):
        super(Janela, self).__init__()
        self.title(Str)
        self.geometry("%sx%s+%s+%s" % (dx, dy, x1, y1))
        self.configure(bg=cor)

        self.inicialize()

    def action_Bt1(self):
        self.Txt1.insert(END, "Botão 1:\n")

    def action_Bt2(self):
        self.Txt1.insert(END, "Botão 2:\n")

    def action_Bt3(self):
        self.Txt1.insert(END, "Botão 3:\n")

    def action_Bt4(self):
        self.Txt1.insert(END, "Botão 4:\n")

    def inicialize(self):
        Bt1=Button(self, text='Botão 1', command=self.action_Bt1, cursor='watch')
        Bt2=Button(self, text='Botão 2', command=self.action_Bt2)
        Bt3=Button(self, text='Botão 3', command=self.action_Bt3)
        Bt4=Button(self, text='Botão 4', command=self.action_Bt4)

        self.Txt1=Text(self, height=8, width=40) # Para tornar o objeto Txt1 visível no evento é obrigatório usar a palavra self.Txt1

        self.iconbitmap('./Icon/Python_32x32.ico')

        Bt1.grid(row=0, column=0, sticky=NW, padx=4, pady=4)
        Bt2.grid(row=0, column=1, sticky=NW, padx=4, pady=4)
        Bt3.grid(row=0, column=2, sticky=NW, padx=4, pady=4)
        Bt4.grid(row=0, column=3, sticky=NW, padx=4, pady=4)
        self.Txt1.grid(row=2, column=0, sticky=NW, columnspan=4, padx=4, pady=4)

########################################################################################################################

Jan1=Janela("Minha janela", "400", "200", "540", "380", "orange")
Jan1.mainloop()
