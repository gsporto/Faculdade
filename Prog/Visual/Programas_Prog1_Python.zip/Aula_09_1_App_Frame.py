from tkinter import *

def action_show2():
    Jan2.state(newstate="withdraw")
    Janela.focus()

def Show_Janela2():
    Jan2.state(newstate="normal")
    Jan2.focus()

def action_show():
    # print("First Name: %s\nLast Name: %s" % (Et1.get(), Et2.get()))
    Txt1.insert(END, "First Name: %s\nLast Name: %s\n" % (Et1.get(), Et2.get()))
    Show_Janela2()

########################################################################################################################

Janela = Tk()
Janela.title("Minha janela")
Janela.geometry("540x380+400+200")
Janela.configure(bg='orange')

Lb1=Label(Janela, text="First Name")
Lb2=Label(Janela, text="Last Name")
Lb3=Label(Janela, text="Text área")

Et1=Entry(Janela, width=52)
Et2=Entry(Janela, width=52)

Txt1=Text(Janela, height=8, width=40)

Bt1=Button(Janela, text='Quit', command=Janela.quit) ## Janela.mainloop( )
Bt2=Button(Janela, text='New window', command=action_show)

Lb1.grid(row=0, column=0)
Lb2.grid(row=1, column=0)
Lb3.grid(row=3, column=0)
Et1.grid(row=0, column=1, columnspan=2)
Et2.grid(row=1, column=1, columnspan=2)
Txt1.grid(row=3, column=1, columnspan=2)
Bt1.grid(row=4, column=1, sticky=E, padx=4, pady=4)
Bt2.grid(row=4, column=2, sticky=W, padx=4, pady=4)

Jan2 = Toplevel(Janela)
Jan2.title('top/child window win1')
Jan2.geometry("320x240+500+250")
Jan2.configure(bg='yellow')
Lb12=Label(Jan2, text='Janela2')
Bt12=Button(Jan2, text='Sair', command=action_show2)
Lb12.grid(row=0, column=0, padx=4, pady=4)
Bt12.grid(row=0, column=1, padx=4, pady=4)
Jan2.state(newstate="withdraw")

Janela.mainloop( )
