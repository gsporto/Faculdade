from tkinter import *
from tkinter import messagebox

class Janela_Top(Toplevel):
    def __init__(self, Master, Str="Janela", x1="0", y1="0", dx="640", dy="480", cor="ligthgray"):
        super(Janela_Top, self).__init__(Master)
        super(Janela_Top, self).title(Str)
        super(Janela_Top, self).geometry("%sx%s+%s+%s" % (dx, dy, x1, y1))
        super(Janela_Top, self).configure(bg=cor)

        self.inicialize()

    def inicialize(self):
        Lb1=Label(self, text="First Name")
        Lb1.grid(row=0, column=0)

########################################################################################################################

class Janela(Tk):
    def __init__(self, Str="Janela", x1="0", y1="0", dx="640", dy="480", cor="ligthgray"):
        super(Janela, self).__init__()
        super(Janela, self).title(Str)
        super(Janela, self).geometry("%sx%s+%s+%s" % (dx, dy, x1, y1))
        super(Janela, self).configure(bg=cor)

        self.inicialize()
        self.init_menu()

    def action_window(self):
        Jan2 = Janela_Top(self, "Minha janela", "600", "400", "340", "280", "cyan")

    def action_quit(self):
        self.quit()

    def action_save(self):
        num = messagebox.askquestion("Título da janela", "Pergunta")
        print(num)

    def inicialize(self):
        Lb1=Label(self, text="First Name")
        Lb2=Label(self, text="Last Name")
        Lb3=Label(self, text="Text área")

        Et1=Entry(self, width=52)
        Et2=Entry(self, width=52)

        Txt1=Text(self, height=8, width=40)

        Bt1=Button(self, text='Quit', command=self.action_quit)
        Bt2=Button(self, text='New window', command=self.action_window)

        Lb1.grid(row=0, column=0)
        Lb2.grid(row=1, column=0)
        Lb3.grid(row=3, column=0)
        Et1.grid(row=0, column=1, columnspan=2)
        Et2.grid(row=1, column=1, columnspan=2)
        Txt1.grid(row=3, column=1, columnspan=2)
        Bt1.grid(row=4, column=1, sticky=E, padx=4, pady=4)
        Bt2.grid(row=4, column=2, sticky=W, padx=4, pady=4)

    def init_menu(self):
        menubar = Menu(self)

        # create a pulldown menu, and add it to the menu bar
        filemenu = Menu(menubar, tearoff=0)
        filemenu.add_command(label="Open", command=self.action_window)
        filemenu.add_command(label="Save", command=self.action_save)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=self.action_quit)
        menubar.add_cascade(label="File", menu=filemenu)

        # create more pulldown menus
        editmenu = Menu(menubar, tearoff=0)
        editmenu.add_command(label="Cut")
        editmenu.add_command(label="Copy")
        editmenu.add_command(label="Paste")
        menubar.add_cascade(label="Edit", menu=editmenu)

        helpmenu = Menu(menubar, tearoff=0)
        helpmenu.add_command(label="About", command=self.action_save)
        menubar.add_cascade(label="Help", menu=helpmenu)

        # display the menu
        self.config(menu=menubar)

########################################################################################################################

Jan1=Janela("Minha janela", "400", "200", "540", "380", "orange")
Jan1.mainloop( )
