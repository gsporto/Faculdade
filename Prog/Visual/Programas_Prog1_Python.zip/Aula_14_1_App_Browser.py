import webbrowser
webbrowser.open('file://C:/__Work/__Udesc/__Ensino/__Python3_Prog101/Html/Pagina1.html')
