from tkinter import *

class Janela(Tk):
    __Et_Nota1=None
    __Et_Nota2=None
    __Et_Nota3=None
    __Et_Media=None
    def __init__(self, Str="Janela", x1="0", y1="0", dx="640", dy="480", cor="ligthgray"):
        super().__init__()
        super().title(Str)
        super(Janela, self).geometry("%sx%s+%s+%s" % (dx, dy, x1, y1))
        super(Janela, self).configure(bg=cor)

        self.inicialize()

    def action_Bt_Calc(self):
        n1=float(self.__Et_Nota1.get())
        n2=float(self.__Et_Nota2.get())
        n3=float(self.__Et_Nota3.get())
        total=(n1+n2+n3)/3
        ## n=len(self.__Et_Media.get())
        ## self.__Et_Media.delete(0, n)
        self.__Et_Media.delete(0, END)
        self.__Et_Media.insert(END, "%f" % total)

    def inicialize(self):
        Lb_Nome=Label(self, text="Nome=")
        Lb_Sexo=Label(self, text="Sexo=")
        Lb_Nota1=Label(self, text="Nota1=")
        Lb_Nota2=Label(self, text="Nota2=")
        Lb_Nota3=Label(self, text="Nota3=")
        Lb_Media=Label(self, text="Media=")

        Lb_Nome.configure(bg='yellow')
        Lb_Sexo.configure(bg='yellow')
        Lb_Nota1.configure(bg='yellow')
        Lb_Nota2.configure(bg='yellow')
        Lb_Nota3.configure(bg='yellow')
        Lb_Media.configure(bg='yellow')

        Et_Nome=Entry(self, width=52)
        self.__Et_Nota1=Entry(self, width=52)
        self.__Et_Nota2=Entry(self, width=52)
        self.__Et_Nota3=Entry(self, width=52)
        self.__Et_Media=Entry(self, width=52)

        # Lbox_Sexo=Listbox(self, width=52, listvariable=('Escolha a opção', 'Masc.', 'Fem.'))
        # Lbox_Sexo.insert(1, 'Escolha a opção')
        # Lbox_Sexo.insert(2, 'Masc.')
        # Lbox_Sexo.insert(3, 'Fem.')
        var=StringVar(self)
        var.set('Escolha a opção')
        OM_Sexo=OptionMenu(self, var, 'Escolha a opção', 'Masc.', 'Fem.')
        OM_Sexo.config(width=32)

        Bt_Calc=Button(self, text='Calcular', command=self.action_Bt_Calc)

        Lb_Nome.grid(row=0, column=0, sticky=NW, padx=4, pady=4)
        Lb_Sexo.grid(row=1, column=0, sticky=NW, padx=4, pady=4)
        Lb_Nota1.grid(row=2, column=0, sticky=NW, padx=4, pady=4)
        Lb_Nota2.grid(row=3, column=0, sticky=NW, padx=4, pady=4)
        Lb_Nota3.grid(row=4, column=0, sticky=NW, padx=4, pady=4)
        Lb_Media.grid(row=5, column=0, sticky=NW, padx=4, pady=4)
        Bt_Calc.grid(row=6, column=0, sticky=NW, padx=4, pady=4)

        Et_Nome.grid(row=0, column=1, sticky=NW, padx=4, pady=4)
        OM_Sexo.grid(row=1, column=1, sticky=NW, padx=4, pady=4)
        self.__Et_Nota1.grid(row=2, column=1, sticky=NW, padx=4, pady=4)
        self.__Et_Nota2.grid(row=3, column=1, sticky=NW, padx=4, pady=4)
        self.__Et_Nota3.grid(row=4, column=1, sticky=NW, padx=4, pady=4)
        self.__Et_Media.grid(row=5, column=1, sticky=NW, padx=4, pady=4)

########################################################################################################################

Jan1=Janela("Minha janela", "400", "200", "540", "380", "orange")
Jan1.mainloop( )
