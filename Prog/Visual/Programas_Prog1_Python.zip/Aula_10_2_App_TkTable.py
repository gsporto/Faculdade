from tkinter import *

def action_event():
    Frm1.configure(bg='green', width='100', height='100')
    for rw in rows:
        Texto=""
        for cl in rw:
            Texto+="%s,  " % cl.get()
        print(Texto)
    print()

J1 = Tk()
J1.title("Minha J1")
J1.geometry("540x410+400+200")
J1.configure(bg='orange')

Frm1=Frame(J1, width=100, height=80,bd=2)
Frm1.grid(row=0, column=0)
Frm1.configure(bg='cyan')

Cnv1=Canvas(Frm1, width=300, height=260, confine=False, yscrollincrement=10, scrollregion=(0,0,300,260))
Cnv1.grid(row=0, column=0)
Cnv1.configure(bg='yellow', scrollregion="0 0 200 160")
Cnv1.xview_moveto(0)
Cnv1.yview_moveto(0)

Frm1.interior = interior = Frame(Cnv1)
interior_id = Cnv1.create_window(0,0,window=interior,anchor=NW);

# track changes to the canvas and frame width and sync them,
# also updating the scrollbar
def _configure_interior(event):
    # update the scrollbars to match the size of the inner frame
    size = (interior.winfo_reqwidth(), interior.winfo_reqheight())
    Cnv1.config(scrollregion="0 0 %s %s" % size)
    if interior.winfo_reqwidth() != Cnv1.winfo_width():
        # update the canvas's width to fit the inner frame
        Cnv1.config(width=interior.winfo_reqwidth())
interior.bind('<Configure>', _configure_interior)

def _configure_canvas(event):
    if interior.winfo_reqwidth() != Cnv1.winfo_width():
        # update the inner frame's width to fill the canvas
        Cnv1.itemconfigure(interior_id, width=Cnv1.winfo_width())
Cnv1.bind('<Configure>', _configure_canvas)

Sb1=Scrollbar(Frm1, orient="vertical")

Frm2=Frame(J1)
Frm2.grid(row=1, column=0)
Frm2.configure(bg='red')

nlin=16
ncol=4
rows = []
for i in range(nlin):
    cols = []
    for j in range(ncol):
        Et1=Entry(interior, relief=RIDGE)
        Et1.grid(row=i, column=j, sticky=NSEW, padx=2, pady=2)
        Et1.insert(END, '%d.%d' % (i, j))
        cols.append(Et1)
    rows.append(cols)

Sb1.grid(row=0, column=ncol, rowspan=nlin, sticky=NS)
Sb1.set(0,10)
Sb1.config(command=Cnv1.yview)
Cnv1.config(yscrollcommand=Sb1.set)

Bt1=Button(Frm2, text='Print', padx=1, pady=1, command=action_event)
Bt1.grid(row=0, column=0, sticky=E, padx=120)
mainloop()
