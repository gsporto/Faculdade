num1=int(input("Digite o primeiro valor inteiro: "))
num2=int(input("Digite o segundo valor inteiro: "))

result=float(num1/num2)

print("Resultado: %f" % result)
