
Vect_Str=[]

with open("./texto.txt", "r") as file:
    Data=file.readlines()

for line in Data:
    Vect_Str.append("%s" % line.replace("\n",""))

for i in range(0, len(Vect_Str),1):
    print("Vect_Str[%d] --> %s" % (i, Vect_Str[i])) # o comando print já põe um \n
