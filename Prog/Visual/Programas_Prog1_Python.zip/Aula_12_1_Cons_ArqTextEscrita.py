
Vect_Str=[]
Vect_Str.append("Nome=Maria da Silva Idade=61")
Vect_Str.append("Nome=Mauricio Andre da Silva Idade=22")
Vect_Str.append("Nome=Tureck Idade=25")

file=open("./texto.txt", "w")
for i in range(0, len(Vect_Str),1):
    file.write("%s\n" % Vect_Str[i])
    print("Vect_Str[%d] --> %s" % (i, Vect_Str[i])) # o comando print já põe um \n
file.close()
