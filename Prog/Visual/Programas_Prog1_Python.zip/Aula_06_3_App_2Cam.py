from tkinter import *
from Aluno import Aluno

class Janela(Tk):
    __Alu=None
    __Et_Nota1 = None
    __Et_Nota2 = None
    __Et_Nota3 = None
    __Et_Media = None
    def __init__(self, Str="Janela", x1="0", y1="0", dx="640", dy="480", cor="ligthgray"):
        super().__init__()
        super().title(Str)
        super(Janela, self).geometry("%sx%s+%s+%s" % (dx, dy, x1, y1))
        super(Janela, self).configure(bg=cor)

        self.inicialize()

    def action_Bt_Calc(self):
        n1=float(self.__Et_Nota1.get())
        n2=float(self.__Et_Nota2.get())
        n3=float(self.__Et_Nota3.get())

        self.__Alu.set_Nota1(n1)
        self.__Alu.set_Nota2(n2)
        self.__Alu.set_Nota3(n3)
        self.__Alu.Calcula_Media()

        self.__Et_Media.delete(0, END)
        self.__Et_Media.insert(END, "%f" % self.__Alu.get_Media())

    def inicialize(self):
        Lb_Nome=Label(self, text="Nome=")
        Lb_Sexo=Label(self, text="Sexo=")
        Lb_Nota1=Label(self, text="Nota1=")
        Lb_Nota2=Label(self, text="Nota2=")
        Lb_Nota3=Label(self, text="Nota3=")
        Lb_Media=Label(self, text="Media=")

        Lb_Nome.configure(bg='yellow')
        Lb_Sexo.configure(bg='yellow')
        Lb_Nota1.configure(bg='yellow')
        Lb_Nota2.configure(bg='yellow')
        Lb_Nota3.configure(bg='yellow')
        Lb_Media.configure(bg='yellow')

        Et_Nome=Entry(self, width=52)
        self.__Et_Nota1=Entry(self, width=52)
        self.__Et_Nota2=Entry(self, width=52)
        self.__Et_Nota3=Entry(self, width=52)
        self.__Et_Media=Entry(self, width=52)

        # Lbox_Sexo=Listbox(self, width=52, listvariable=('Escolha a opção', 'Masc.', 'Fem.'))
        # Lbox_Sexo.insert(1, 'Escolha a opção')
        # Lbox_Sexo.insert(2, 'Masc.')
        # Lbox_Sexo.insert(3, 'Fem.')
        var=StringVar(self)
        var.set('Escolha a opção')
        OM_Sexo=OptionMenu(self, var, 'Escolha o sexo', 'Masculino', 'Feminino')
        OM_Sexo.config(width=32)

        Bt_Calc=Button(self, text='Calcular', command=self.action_Bt_Calc)

        Lb_Nome.grid(row=0, column=0, sticky=NW, padx=4, pady=4)
        Lb_Sexo.grid(row=1, column=0, sticky=NW, padx=4, pady=4)
        Lb_Nota1.grid(row=2, column=0, sticky=NW, padx=4, pady=4)
        Lb_Nota2.grid(row=3, column=0, sticky=NW, padx=4, pady=4)
        Lb_Nota3.grid(row=4, column=0, sticky=NW, padx=4, pady=4)
        Lb_Media.grid(row=5, column=0, sticky=NW, padx=4, pady=4)
        Bt_Calc.grid(row=6, column=0, sticky=NW, padx=4, pady=4)

        Et_Nome.grid(row=0, column=1, sticky=NW, padx=4, pady=4)
        OM_Sexo.grid(row=1, column=1, sticky=NW, padx=4, pady=4)
        self.__Et_Nota1.grid(row=2, column=1, sticky=NW, padx=4, pady=4)
        self.__Et_Nota2.grid(row=3, column=1, sticky=NW, padx=4, pady=4)
        self.__Et_Nota3.grid(row=4, column=1, sticky=NW, padx=4, pady=4)
        self.__Et_Media.grid(row=5, column=1, sticky=NW, padx=4, pady=4)

        self.__Alu=Aluno()
        self.__Alu.set_Nome('Joao')
        self.__Alu.set_Sexo('Masculino')
        self.__Alu.set_Nota1(1)
        self.__Alu.set_Nota2(2)
        self.__Alu.set_Nota3(4)
        self.__Alu.Calcula_Media()

        Et_Nome.insert(END, self.__Alu.get_Nome())
        var.set(self.__Alu.get_Sexo())
        self.__Et_Nota1.insert(END, self.__Alu.get_Nota1())
        self.__Et_Nota2.insert(END, self.__Alu.get_Nota2())
        self.__Et_Nota3.insert(END, self.__Alu.get_Nota3())
        self.__Et_Media.insert(END, self.__Alu.get_Media())

########################################################################################################################

Jan1=Janela("Minha janela", "400", "200", "540", "380", "orange")
Jan1.mainloop( )
