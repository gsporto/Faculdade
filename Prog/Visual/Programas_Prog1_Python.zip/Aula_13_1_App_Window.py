from tkinter import *

def action_new_window():
    j2=Janela2("Minha janela2", "600", "400", "340", "280", "cyan")

class Janela2(Tk):
    def __init__(self, Str="Janela", x1="0", y1="0", dx="640", dy="480", cor="ligthgray"):
        super(Janela2, self).__init__()
        super(Janela2, self).title(Str)
        super(Janela2, self).geometry("%sx%s+%s+%s" % (dx, dy, x1, y1))
        super(Janela2, self).configure(bg=cor)
        self.inicialize()

    def inicialize(self):
        Lb1=Label(self, text="First Name")
        Lb1.grid(row=0, column=0)

class Janela(Tk):
    def __init__(self, Str="Janela", x1="0", y1="0", dx="640", dy="480", cor="ligthgray"):
        super(Janela, self).__init__()
        super(Janela, self).title(Str)
        super(Janela, self).geometry("%sx%s+%s+%s" % (dx, dy, x1, y1))
        super(Janela, self).configure(bg=cor)
        self.inicialize()

    def inicialize(self):
        Lb1=Label(self, text="First Name")

        Bt1=Button(self, text='Botão 1', command=action_new_window)

        Lb1.grid(row=0, column=0)
        Bt1.grid(row=0, column=1, sticky=E, padx=4, pady=4)

Jan1 = Janela("Minha janela 13_1", "400", "200", "540", "380", "orange")

mainloop( )
