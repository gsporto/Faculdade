from tkinter import *

class Janela(Tk):
    def __init__(self, Str="Janela", x1="0", y1="0", dx="640", dy="480", cor="ligthgray"):
        super().__init__() ##Versao Python 3
        super().title(Str) ##Versao Python 3
        super(Janela, self).geometry("%sx%s+%s+%s" % (dx, dy, x1, y1))
        super(Janela, self).configure(bg=cor)

        self.inicialize()

    def inicialize(self):
        Frm1 = Frame(self)
        Frm1.pack(fill=X)
        Frm1.configure(bg='cyan')

        Frm2 = Frame(self)
        Frm2.pack(fill=X)
        Frm2.configure(bg='red')

        Frm3 = Frame(self)
        Frm3.pack(fill=X)
        Frm3.configure(bg='green')

        Frm4 = Frame(self)
        Frm4.pack(fill=X)
        Frm4.configure(bg='blue')

        Lb1 = Label(Frm1, text="First Name")
        Lb2 = Label(Frm2, text="Last Name")
        Lb3 = Label(Frm3, text="Text área")

        Et1 = Entry(Frm1, width=52)
        Et2 = Entry(Frm2, width=52)

        Txt1 = Text(Frm3, height=8, width=40)

        Bt1 = Button(Frm4, text='Botão 1')
        Bt2 = Button(Frm4, text='Botão 2')

        Lb1.pack(side=LEFT, padx=4, pady=4)
        Lb2.pack(side=LEFT, padx=4, pady=4)
        Lb3.pack(side=LEFT, anchor=N, padx=4, pady=4)
        Et1.pack(fill=X, padx=4, pady=4)
        Et2.pack(fill=X, padx=4, pady=4)
        Txt1.pack(fill=BOTH, pady=4, padx=4, expand=True)
        Bt1.pack(side=LEFT, padx=80, pady=4)
        Bt2.pack(side=LEFT, padx=4, pady=4)

########################################################################################################################

Jan1=Janela("Minha janela", "400", "200", "540", "380", "orange")
Jan1.mainloop()
