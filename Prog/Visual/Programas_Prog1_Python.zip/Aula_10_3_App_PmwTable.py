from tkinter import *
import Pmw

class Demo:
    def __init__(self, parent):
        # Create the ScrolledCanvas.
        self.sc = Pmw.ScrolledCanvas(parent,
                borderframe = 1,
                labelpos = 'nw',
                labelmargin = 2,
                scrollmargin = 2,
                label_text = 'Column1                        | Column2                        | Column3                        | Column4',
                usehullsize = 1,
                hull_width = 400,
                hull_height = 300,
        )

        buttonBox = Pmw.ButtonBox(parent)
        buttonBox.pack(side = 'bottom')
        buttonBox.add('Print', text = 'Print', command = self.print_event)
        buttonBox.add('Quit', text = 'Quit', command = parent.quit)

        # Pack this last so that the buttons do not get shrunk when
        # the window is resized.
        self.sc.pack(padx = 5, pady = 5, fill = 'both', expand = 1)

        nlin=16
        ncol=4
        rows = []
        for i in range(nlin):
            cols = []
            for j in range(ncol):
                Et1=Entry(self.sc.interior(), relief=RIDGE)
                Et1.grid(row=i, column=j, sticky=NSEW, padx=2, pady=2)
                Et1.insert(END, '%d.%d' % (i, j))
                cols.append(Et1)
                self.sc.create_window(126*j, 22*i, anchor='nw', window = Et1)
            rows.append(cols)

        # Set the scroll region of the canvas to include all the items
        # just created.
        self.sc.resizescrollregion()

        self.colours = ('red', 'green', 'blue', 'yellow', 'cyan', 'magenta',
                'black', 'white')
        self.oval_count = 0
        self.rand = 12345

    def print_event(self):
        print(self.sc.yview())

J1 = Tk()
J1.title("Minha J1")
J1.geometry("540x380+400+200")
J1.configure(bg='orange')

P=Demo(J1)

mainloop( )
