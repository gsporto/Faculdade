from tkinter import *

class Janela(Tk):
    def __init__(self, Str="Janela", x1="0", y1="0", dx="640", dy="480", cor="ligthgray"):
        super(Janela, self).__init__()
        super(Janela, self).title(Str)
        super(Janela, self).geometry("%sx%s+%s+%s" % (dx, dy, x1, y1))
        super(Janela, self).configure(bg=cor)

        self.inicialize()

    def Posiciona_Componentes(self):
        self.Lb1.place(x=0, y=10)
        self.Lb2.place(x=0, y=40)
        self.Lb3.place(x=0, y=70)
        self.Et1.place(x=80, y=10)
        self.Et2.place(x=80, y=40)
        self.Txt1.place(x=80, y=70)
        self.Bt1.place(x=140, y=220)
        self.Bt2.place(x=240, y=220)

    def inicialize(self):
        self.Lb1 = Label(self, text="First Name", height=1, width=10)
        self.Lb2 = Label(self, text="Last Name", height=1, width=10)
        self.Lb3 = Label(self, text="Text área", height=1, width=10)

        self.Et1 = Entry(self, width=40)
        self.Et2 = Entry(self, width=40)

        self.Txt1 = Text(self, height=8, width=40)

        self.Bt1 = Button(self, text='Botão 1', height=1, width=10)
        self.Bt2 = Button(self, text='Botão 2', height=1, width=10)

        self.Posiciona_Componentes()

########################################################################################################################

Jan1=Janela("Minha janela", "400", "200", "540", "380", "orange")
Jan1.mainloop()
