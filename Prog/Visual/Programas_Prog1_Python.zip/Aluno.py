
class Aluno():
    __Nome=''
    __Sexo='Escolha o sexo'
    __Nota1=0.0
    __Nota2=0.0
    __Nota3=0.0
    __Media=10.0

    def __init__(self):
        self.__Nome=''
        self.__Sexo='Escolha o sexo'
        self.__Nota1=0.0
        self.__Nota2=0.0
        self.__Nota3=0.0
        self.__Media=0.0
        self.Calcula_Media()

    def Calcula_Media(self):
        self.__Media=(self.__Nota1+self.__Nota2+self.__Nota3)/3

    def get_Nome(self):
        return(self.__Nome)

    def get_Sexo(self):
        return(self.__Sexo)

    def get_Nota1(self):
        return(self.__Nota1)

    def get_Nota2(self):
        return(self.__Nota2)

    def get_Nota3(self):
        return(self.__Nota3)

    def get_Media(self):
        return(self.__Media)

    def set_Nome(self, nome):
        self.__Nome=nome

    def set_Sexo(self, sexo):
        self.__Sexo=sexo

    def set_Nota1(self, nota1):
        self.__Nota1=nota1

    def set_Nota2(self, nota2):
        self.__Nota2=nota2

    def set_Nota3(self, nota3):
        self.__Nota3=nota3
