from tkinter import *

class Janela2(Frame):
    def __init__(self, Str="Janela", x1="0", y1="0", dx="640", dy="480", cor="ligthgray"):
        Root2=Tk()
        Frame.__init__(self, Root2)
        Root2.title(Str)
        Root2.geometry("%sx%s+%s+%s" % (dx, dy, x1, y1))
        Root2.configure(bg=cor)
        self.inicialize(Root2)

    def inicialize(self, parent):
        Lb1=Label(parent, text="First Name")
        Lb1.grid(row=0, column=0)

class Janela(Frame):
    def __init__(self, Str="Janela", x1="0", y1="0", dx="640", dy="480", cor="ligthgray"):
        Root1=Tk()
        Frame.__init__(self, Root1)
        Root1.title(Str)
        Root1.geometry("%sx%s+%s+%s" % (dx, dy, x1, y1))
        Root1.configure(bg=cor)
        self.inicialize(Root1)

    def action_new_window(self):
        j2=Janela2("Minha janela2", "600", "400", "340", "280", "cyan")

    def inicialize(self, parent):
        Lb1=Label(parent, text="First Name")

        Bt1=Button(parent, text='Botão 1', command=self.action_new_window)

        Lb1.grid(row=0, column=0)
        Bt1.grid(row=0, column=1, sticky=E, padx=4, pady=4)

Jan1 = Janela("Minha janela 13_2", "400", "200", "540", "380", "orange")

mainloop( )
