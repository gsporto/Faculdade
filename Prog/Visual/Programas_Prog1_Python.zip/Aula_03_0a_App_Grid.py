from tkinter import *

J1 = Tk()
J1.title("Minha J1")
J1.geometry("540x380+400+200")
J1.configure(bg='orange')

Lb1=Label(J1, text="First Name")
Lb2=Label(J1, text="Last Name")
Lb3=Label(J1, text="Text area")

Et1=Entry(J1, width=52)
Et2=Entry(J1, width=52)

Txt1=Text(J1, height=8, width=40)

Bt1=Button(J1, text='Botão 1')
Bt2=Button(J1, text='Botão 2')

Lb1.grid(row=0, column=0)
Lb2.grid(row=1, column=0)
Lb3.grid(row=2, column=0)
Et1.grid(row=0, column=1, columnspan=2)
Et2.grid(row=1, column=1, columnspan=2)
Txt1.grid(row=2, column=1, columnspan=2)
Bt1.grid(row=3, column=1, sticky=E, padx=4, pady=4)
Bt2.grid(row=3, column=2, sticky=W, padx=4, pady=4)

J1.mainloop( )
